/*
Copyright (c) 2025 PACEPLAN.us and Gabe Elias. All rights reserved.
This work is licensed under the terms of the LICENSE file, which can be found in the root directory of this project.
*/
document.addEventListener('DOMContentLoaded', function() {
    const searchForm = document.getElementById('search-form');
    const loadingSpinner = document.getElementById('loading-spinner');

    if (searchForm && loadingSpinner) {
        searchForm.addEventListener('submit', function() {
            // Show the spinner when the form is submitted
            loadingSpinner.classList.remove('hidden');
            loadingSpinner.classList.add('flex');
        });
    }

    // The spinner is hidden by default. When the page reloads with results,
    // it will naturally be hidden again. This works perfectly for a traditional
    // multi-page application like this one.
});